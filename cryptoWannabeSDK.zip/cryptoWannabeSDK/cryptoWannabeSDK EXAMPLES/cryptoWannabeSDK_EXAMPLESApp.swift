//
//  cryptoWannabeSDK_EXAMPLESApp.swift
//  cryptoWannabeSDK EXAMPLES
//
//  Created by Michał Fereniec on 09/11/2022.
//

import SwiftUI

@main
struct cryptoWannabeSDK_EXAMPLESApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
