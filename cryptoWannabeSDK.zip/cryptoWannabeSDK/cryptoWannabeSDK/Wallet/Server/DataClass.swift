//
//  DataClass.swift
//  cryptoWannabeSDK
//
//  Created by Michał Fereniec on 23/11/2022.
//

import Foundation

struct DataClass: Codable {
    let profile
}
