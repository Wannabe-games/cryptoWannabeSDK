//
//  STXAddress.swift
//  cryptoWannabeSDK
//
//  Created by Michał Fereniec on 23/11/2022.
//

import Foundation

struct STXAddress: Codable {
    let testnet: String
    let mainnet: String
}
