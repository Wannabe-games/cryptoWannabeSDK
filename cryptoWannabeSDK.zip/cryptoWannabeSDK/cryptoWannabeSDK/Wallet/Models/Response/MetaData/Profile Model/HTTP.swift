//
//  HTTP.swift
//  cryptoWannabeSDK
//
//  Created by Michał Fereniec on 23/11/2022.
//

import Foundation

struct HTTP: Codable {
    let storage: String
    let publicKey: String
}
