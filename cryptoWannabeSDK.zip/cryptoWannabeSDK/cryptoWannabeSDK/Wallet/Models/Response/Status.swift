//
//  Status.swift
//  cryptoWannabeSDK
//
//  Created by Michał Fereniec on 22/11/2022.
//

import Foundation

enum Status: String, Codable {
    case success
    case error
}
