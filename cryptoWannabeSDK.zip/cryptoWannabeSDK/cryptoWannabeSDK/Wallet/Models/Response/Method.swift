//
//  Method.swift
//  cryptoWannabeSDK
//
//  Created by Michał Fereniec on 22/11/2022.
//

import Foundation

enum Method: String, Codable {
    case GET
    case POST
}
