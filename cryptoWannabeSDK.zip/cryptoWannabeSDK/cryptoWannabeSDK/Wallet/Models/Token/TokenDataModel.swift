//
//  TokenDataModel.swift
//  CryptoWannabeSDK
//
//  Created by Michał Fereniec on 01/12/2022.
//

import Foundation

struct TokenDataModel: Decodable {
    let token: String
}
