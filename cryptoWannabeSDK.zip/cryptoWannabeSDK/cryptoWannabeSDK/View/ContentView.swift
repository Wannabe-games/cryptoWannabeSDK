//
//  ContentView.swift
//  cryptoWannabeSDK
//
//  Created by Michał Fereniec on 21/11/2022.
//

import SwiftUI
import WebKit

struct ContentView: View {
        
    var body: some View {
        Text("Hello")
    }
}
