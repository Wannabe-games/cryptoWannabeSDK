//
//  cryptoWannabeSDK.h
//  cryptoWannabeSDK
//
//  Created by Michał Fereniec on 09/11/2022.
//

#import <Foundation/Foundation.h>

//! Project version number for cryptoWannabeSDK.
FOUNDATION_EXPORT double cryptoWannabeSDKVersionNumber;

//! Project version string for cryptoWannabeSDK.
FOUNDATION_EXPORT const unsigned char cryptoWannabeSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <cryptoWannabeSDK/PublicHeader.h>


