//
//  WKWebView.swift
//  cryptoWannabeSDK
//
//  Created by Michał Fereniec on 21/11/2022.
//

import Foundation

class ViewController : UIViewController, WKUIDelegate {
    
}
